<!DOCTYPE html>
<html>

<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="css/style.css" />

  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
</head>

<body class="grey lighten-4">
  <nav class="grey darken-4">
    <div class="container">
      <div class="nav-wrapper">
        <a href="index.php" class="brand-logo"><img src="img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
            <a href="#" data-activates="side-nav" class="button-collapse show-on-large right">
              <i class="material-icons">menu</i>
            </a>
            <ul class="right hide-on-med-and-down">
              <li class="active">
                <a href="index.php">Home</a>
              </li>
              <li>
                <a href="posts.php">Statistics</a>
              </li>
              <li>
                <a href="categories.php">Incidents</a>
              </li>
              <li>
                <a href="comments.php">Contact</a>
              </li>
              <li>
                <a href="users.php">About Us</a>
              </li>
            </ul>
            </div>
          </div>
        </nav>
      </div>
        <!-- Side nav -->
        <ul id="side-nav" class="side-nav">
        <!-- <li>
          <div class="user-view">
            <div class="background">
              <img src="img/ocean.jpg" alt="">
            </div>
            <a href="#">
              <img src="img/person1.jpg" alt="" class="circle">
            </a>
            <a href="#">
              <span class="name white-text">John Doe</span>
            </a>
            <a href="#">
              <span class="email white-text">jdoe@gmail.com</span>
            </a>
          </div>
        </li> -->
        <li class="active">
          <a href="index.php">Home</a>
        </li>
        <li>
          <a href="posts.php">Statistics</a>
        </li>
        <li>
          <a href="categories.php">Incidents</a>
        </li>
        <li>
          <a href="comments.php">Contact</a>
        </li>
        <li>
          <a href="users.php">About Us</a>
        </li>
      </ul>
      </div>
    </div>
  </nav>

  <section class="section grey lighten-2 center black-text">
    <div class="container">
      <div class="row">
        <h4>Seek Help from Fire Station</h4>
        <p>Please varify Your place.</p>
        <div class="divider grey lighten-2"></div>
        <form action="upload.php" method="post" enctype="multipart/form-data">
          <div class="col s12 m4 l4">
            <div class="input-field">
              <i class="material-icons prefix">location_on</i>
              <input id="phone" type="tel">
              <label for="phone">Location</label>
            </div>
           </div>

           <div class="col s12 m4 l4">
             <div class="file-field input-field">
              <div class="btn orange white-text">
                <span>Take a picture of the place.</span>
                <input type="file" accept="images">
              </div>
              <div class="file-path-wrapper">
                <input type="text" class="file-path">
              </div>
            </div>
           </div>
           <div class="col s12 m4 l4">
             <div class="button">
               <button class="btn btn-large orange darken-4 white-text" type="submit">Submit For Help</button>
             </div>
           </div> 
          </form>
        </div>
      </div>
    </div>
  </section>


  <!--Import jQuery before materialize.js-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

  <script>
    // Hide Sections
    $('.section').hide();

    setTimeout(function () {
      $(document).ready(function () {
        // Show sections
        $('.section').fadeIn();

        // Hide preloader
        $('.loader').fadeOut();

        //Init Side nav
        $('.button-collapse').sideNav();

        // Init Modal
        $('.modal').modal();

        // Init Select
        $('select').material_select();

        // Counter
        $('.count').each(function () {
          $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
          }, {
              duration: 1000,
              easing: 'swing',
              step: function (now) {
                $(this).text(Math.ceil(now));
              }
            });
        });

        // Comments - Approve & Deny
        $('.approve').click(function (e) {
          Materialize.toast('Comment Approved', 3000);
          e.preventDefault();
        });
        $('.deny').click(function (e) {
          Materialize.toast('Comment Denied', 3000);
          e.preventDefault();
        });

        // Quick Todos
        $('#todo-form').submit(function (e) {
          const output = `<li class="collection-item">
                <div>${$('#todo').val()}
                  <a href="#!" class="secondary-content delete">
                    <i class="material-icons">close</i>
                  </a>
                </div>
              </li>`;

          $('.todos').append(output);

          Materialize.toast('Todo Added', 3000);

          e.preventDefault();
        });

        // Delete Todos
        $('.todos').on('click', '.delete', function (e) {
          $(this).parent().parent().remove();
          Materialize.toast('Todo Removed', 3000);

          e.preventDefault();
        });

        CKEDITOR.replace('body');

      });
    }, 1000);
  </script>
     <script>
  $.ajax({
    url: "https://geoip-db.com/jsonp",
    jsonpCallback: "callback",
    dataType: "jsonp",
    success: function( location ) {
      $('#country').html(location.country_name);
      $('#state').html(location.state);
      $('#city').html(location.city);
      $('#latitude').html(location.latitude);
      $('#longitude').html(location.longitude);
      $('#ipv4').html(location.IPv4);  
    }
  });   
    </script>
</body>

</html>