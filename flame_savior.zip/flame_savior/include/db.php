<?php
	date_default_timezone_set("Asia/Dhaka");
	$currenttime = time();
	$datetime = strftime("%B-%d-%Y %H:%M",$currenttime);
	$datetime;
	
	$conn = mysqli_connect("localhost","root","","flame_savior");
?>