<?php
      include '../include/db.php';
      include '../volunteer/getAddress.php';
      session_start();
      if (!isset($_SESSION['id'])) {
        header("Location:login.php");
      }
?>


<!DOCTYPE html>
<html>

<head>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
  <style type="text/css">
    .showcase{
      background:linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)),url("../img/1.jpg");;
      background-size: cover;
      background-position: center; 
      height: 100vh;
      background-attachment: fixed; 
    }
  </style>
</head>


<body id="home" class="scrollspy">
  <header class="main-header">
    <div class="primary-overlay">
      <div class="navbar">
        <nav class="transparent">
          <div class="container-fluid">
            <div class="nav-wrapper">
              <a href="index.php" class="brand-logo"><img src="../img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
            <a href="#" data-activates="side-nav" class="button-collapse right">
              <i class="material-icons">menu</i>
            </a>
            <ul class="right hide-on-med-and-down">
              <li class="active">
                <a href="index.php"><i class="material-icons">home</i></a>
              </li>
              <li>
                  <a class="dropdown-button" data-activates="dropdown" href="#!"><i class="material-icons">notifications</i>
                  </a>
              </li>
              <li>
                <a href="report.php"><i class="material-icons right">book</i></a>
              </li>
              <li>
                <a href="volunteer.php"><i class="material-icons right">people</i></a>
              </li>
              <li>
                <a href="profile.php?id=<?php echo $_SESSION['id']; ?>"><i class="material-icons right">person</i></a>
              </li>
              <li>
                <a href="logout.php"><i class="material-icons right">exit_to_app</i></a>
              </li>
              
              <li style="margin-left: 20px;">
                <a href="" class="grey-text">Welcome Firefighter</a>
              </li>
            </div>
          </div>
        </nav>
      </div>
      <!-- Dropdowns Notifications -->
      <ul id="dropdown" class="collection with-header latest-comments dropdown-content" style="width: 40%;">
        <li class="collection-header blue-grey">Latest Nofications</li>

        <?php

            $SELECT = mysqli_query($conn, "SELECT * FROM notification
                  JOIN volunteer ON notification.volunteer_id = volunteer.id 
                  JOIN incident ON notification.incident_id = incident.id WHERE notification.status = '0' ORDER BY notification.id DESC LIMIT 0,3");

            while ($not_row=mysqli_fetch_array($SELECT)) {
              $fullname = $not_row['firstname']." ".$not_row['lastname'];
              $lat = $not_row['incident_lat'];
              $long = $not_row['incident_long'];
              $incident_id = $not_row['id'];
              $add = getaddress($lat,$long);
              $incident_time = $not_row['incident_time'];

        ?>
             <li class="collection-item avatar">
              <a href="details.php?id=<?php echo $not_row['id']; ?>"><img src="../upload/<?php echo $not_row['image']; ?>" alt="" class="squire" style="height: 100px; width: 100px;">
              <span class="title black-text">Seeking Help from
                <br>"<?php echo $add; ?>"<br>At <?php echo $incident_time; ?>
                </span>
              </a>
              <span class="button"><a href="confirm_incident.php?id=<?php echo $incident_id; ?>" class="btn green">Confirm</a><a href="details.php?id=<?php echo $incident_id; ?>" class="btn red">Details</a></span>
            </li>
          <?php  } ?>
          <li><a class="center indigo-text" href="notifications.php?uid=<?php // echo $user_id; ?>">See all</a></li>
      </ul>
      <!-- Side nav -->
      <ul id="side-nav" class="side-nav">
      <li class="active">
        <a href="index.php">Home</a>
      </li>
      <li>
        <a href="posts.php">Statistics</a>
      </li>
      <li>
        <a href="categories.php">Incidents</a>
      </li>
      <li>
        <a href="comments.php">Contact</a>
      </li>
      <li>
        <a href="users.php">About Us</a>
      </li>
    </ul>
      <!-- Showcase -->
      <div class="showcase container-fluid">
        <div class="row">
          <div class="col s8 m8 l8 main-text">
          </div>

          <div class="s4 m4 l4 button-emergency ">
            <?php

                  $ready = mysqli_query($conn, "SELECT * FROM notification
                  JOIN volunteer ON notification.volunteer_id = volunteer.id 
                  JOIN incident ON notification.incident_id = incident.id WHERE notification.status = '0' ORDER BY notification.id DESC LIMIT 0,3");

                  if (mysqli_num_rows($ready)==1) {
                    while ($not_row=mysqli_fetch_array($SELECT)) {
                    $fullname = $not_row['firstname']." ".$not_row['lastname'];
                    $lat = $not_row['incident_lat'];
                    $long = $not_row['incident_long'];
                    $incident_id = $not_row['id'];
                    $add = getaddress($lat,$long);
                    $incident_time = $not_row['incident_time'];
                    
             ?>
            <div align="center" class="">
              <img src="../img/down-arrow.gif" style="height: 100px; width: 150px;">
              <p>We Noticed Someone is seeking help from <?php echo $add; ?>..Please Help !</p>
              <a href="notify.php?id=<?php echo $incident_id; ?>" class="btn btn-large red white-text">Notify Fire Station</a>
              <p class="red-text text-lighten-1">Note: Before You Notify Fire station please confirm about the incident first.</p>
            </div>
          <?php } } else{ ?>
            <div align="center" class="">
              <img src="../img/down-arrow.gif" style="height: 100px; width: 150px;">
              <p>We Noticed Someone is seeking help from .Please Help !</p>
              <a href="details.php" class="btn btn-large red white-text">Notify Fire Station</a>
              <p class="red-text text-lighten-1">Note: Before You Notify Fire station please confirm about the incident first.</p>
            </div>
          <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </header>

  <section class="section section-visitors orange lighten-4">
    <div class="row">
      <div class="col s12 m12 l12">
        <div class="card-panel">
          <table class="striped">
            <h4>Recent Incident History</h4>
            <thead>
                <tr>
                  <th>Location</th>
                  <th>Status</th>
                  <th>Incident time</th>
                </tr>
            </thead>
                <?php 

                        $post = mysqli_query($conn, "SELECT * FROM incident WHERE status = '0' LIMIT 0,3");
                        while ($row=mysqli_fetch_array($post)) {
                            $lat = $row['incident_lat'];
                            $lang = $row['incident_long'];
                ?>

                <tr>
                    <td><?php echo $lat." , ".$lang; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo $row['incident_time']; ?></td>
                  <td>
                    <a href="details_view.php?id=<?php echo $row['id']; ?>" class="btn blue lighten-2">Details</a>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>


  <!--Import jQuery before materialize.js-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="../js/materialize.min.js"></script>
  <script>
    $(document).ready(function () {
      $('.dropdown-button').dropdown({
          constrainWidth: false,
          hover: false,
          belowOrigin: false,
          alignment: 'left'
        });

      // JAVASCRIPT START HERE //

      $('.button-collapse').sideNav();


    });


  </script>
</body>

</html>