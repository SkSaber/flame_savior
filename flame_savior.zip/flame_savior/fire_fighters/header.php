<?php
    
    include '../include/db.php';
    session_start();
    if (!isset($_SESSION['id'])) {
      header("Location:login.php");
    }
?>

<!DOCTYPE html>
<html>

<head>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/style.css" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
</head>

<body class="grey lighten-4">
  <nav class="grey darken-4">
    <div class="container">
      <div class="nav-wrapper">
        <a href="index.php" class="brand-logo"><img src="../img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
        <a href="#" data-activates="side-nav" class="button-collapse right">
          <i class="material-icons">menu</i>
        </a>
        <ul class="right hide-on-med-and-down">
          <li class="active">
            <a href="index.php"><i class="material-icons right">home</i></a>
          </li>
          <li class="active">
            <a class="dropdown-button" data-activates="dropdown" href="#!"><i class="material-icons">notifications</i>
                  </a>
          </li>
          <li>
            <a href="report.php"><i class="material-icons right">book</i></a>
          </li>
          <li>
            <a href="volunteer.php"><i class="material-icons right">people</i></a>
          </li>
          <li>
            <a href="profile.php?id=<?php echo $_SESSION['id']; ?>"><i class="material-icons right">person</i></a>
          </li>
          <li>
            <a href="logout.php"><i class="material-icons right">exit_to_app</i></a>
          </li>
          
          <li style="margin-left: 20px;">
            <a href="" class="grey-text">Welcome Firefighter</a>
          </li>
        </ul>
       
        <!-- Side nav -->
        <ul id="side-nav" class="side-nav">
          
          <li class="active">
            <a href="index.php"><i class="material-icons right">home</i></a>
          </li>
          <li class="active">
            <a class="dropdown-button" data-activates="dropdown" href="#!"><i class="material-icons">notifications</i>
            </a>
          </li>
          <li>
            <a href="report.php"><i class="material-icons ">book</i></a>
          </li> 
          <li>
            <a href="volunteer.php"><i class="material-icons ">people</i></a>
          </li>
          <li>
            <a href="profile.php"><i class="material-icons ">person</i></a>
          </li>
          <li>
            <a href="logout.php"><i class="material-icons ">exit_to_app</i></a>
          </li>
          <li>
            <a>Welcome Firefighter</a>
          </li>
        </ul>
      </div>
    </div>
    <!-- Dropdowns Notifications -->
      <ul id="dropdown" class="collection with-header latest-comments dropdown-content" style="width: 40%;">
        <li class="collection-header blue-grey">Latest Nofications</li>

        <?php

            $SELECT = mysqli_query($conn, "SELECT * FROM firefighters_notification fn
                  JOIN volunteer v ON fn.varified_by_id = v.id 
                  JOIN incident i ON fn.incident_id = i.id WHERE fn.status = '0' LIMIT 0,3");

            while ($row=mysqli_fetch_array($SELECT)) {
              $fullname = $row['firstname']." ".$row['lastname'];
           
              

        ?>
             <li class="collection-item avatar">
              <a href="details.php?id=<?php echo $not_row['post_id']; ?>"><img src="upload/<?php echo $not_row['profile_pic']; ?>" alt="" class="circle">
              <span class="title black-text">Seeking Help from
                <br>"<?php //echo $location; ?>"
                </span>
              </a>
              <span class="button"><a href="" class="btn green">Confirm</a><a href="" class="btn red">Deny</a></span>
            </li>
          <?php  } ?>
          <li><a class="center indigo-text" href="notifications.php?uid=<?php // echo $user_id; ?>">See all</a></li>
      </ul>
  </nav>
