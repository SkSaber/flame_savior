<?php 
    include '../include/db.php';
    include 'header.php'; 
  

  if (isset($_POST['add_volunteer'])) {

    $firstname = strip_tags($_POST['firstname']);
    $firstname = str_replace(' ', '', $firstname);
    $firstname = ucfirst(strtolower($firstname));
    $_SESSION['firstname'] = $firstname;

    $lastname = strip_tags($_POST['lastname']);
    $lastname = str_replace(' ', '', $lastname);
    $lastname = ucfirst(strtolower($lastname));
    $_SESSION['lastname'] = $lastname;

    $email = strip_tags($_POST['email']);
    $email = str_replace(' ', '', $email);
    $email = ucfirst(strtolower($email));
    $_SESSION['email'] = $email;

    $status = $_POST['status'];
    $datetime;

  if (filter_var($email, FILTER_VALIDATE_EMAIL))
  {
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    $checkEmail = mysqli_query($conn, "SELECT * FROM volunteer WHERE email = '$email'");
    $rows = mysqli_num_rows($checkEmail);
    if ($rows > 0) 
    {
      echo "Email Exist";
      exit();
      header("Location:volunteer.php");
    }
    
  } 

    $password = substr(str_shuffle(str_repeat("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 8);

    $insert = mysqli_query($conn, "INSERT INTO `volunteer`(`first_name`, `last_name`, `nid`, `email`,`password`, `address_lat`, `address_long`, `training_status`, `training_date`, `status`, `reg_date`) VALUES ('$firstname','$lastname','','$email','$password','','','','','$status','$datetime')");

    if ($insert) {
    $emailTo =  $email;
    $subject = "Fire Fighter Confirmation";
    $body = "Hello ".$firstname.", We are pleasently inform you that, 
          you are Now an active Volunteer Bangladesh Fire Fighters..<br> Please log in with this credentials..<br>
          Email:".$email." <br> Password   ".$password."";

    $headers = "From: atiqur.ra2017@gmail.com";
    if (mail($emailTo, $subject,$body,$headers)) {
      echo "Mail successfuly sent";
    } else {
      echo "Failed";
    }

    } 


  }
?>
  <!-- Section: Categories -->
  <section class="section section-categories grey lighten-4">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card">
            <div class="card-content">
                <span class="card-title">Volunteer<span class="right"><a href="#user-modal" class="modal-trigger btn-large red">Add A Volunteer</a></span></span>
              <table class="striped">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th></th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Activity</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $select = mysqli_query($conn,"SELECT * FROM volunteer");
                      while ($row= mysqli_fetch_array($select)) {
                        $sr = 1;
                  ?>
                  <tr>
                    <td><?php echo $sr; ?></td>
                    <td width="70"></td>
                    <td><?php echo $row['first_name']." ".$row['last_name']; ?></td>
                    <td>Sylhet</td>
                    <td>01705200595</td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php if ($row['status'] == 'Yes'){
                        echo "Active";
                    } else{
                      echo "Inactive";
                    } ?></td>
                  </tr>
                  <?php $sr++; } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Add Fire Fighters Modal -->
  <div id="user-modal" class="modal">
    <div class="modal-content">
      <h4>Add Volunteer</h4>
      <form action="volunteer.php" method="POST">
        <div class="input-field">
          <input type="text" id="firstname" name="firstname">
          <label for="firstname">First Name</label>
        </div>
        <div class="input-field">
          <input type="text" id="lastname" name="lastname">
          <label for="lastname">Last Name</label>
        </div>
        <div class="input-field">
          <input type="email" id="email" name="email">
          <label for="email">Email</label>
        </div>
        <div class="input-field">
          <select class="material-select" name="status">
            <option selected="selected">Activity</option>
            <option value="Yes">Active</option>
            <option value="No">Inactive</option>
          </select>
        </div>
      <div class="modal-footer">
         <input type="submit" name="add_volunteer" class="modal-action modal-close btn blue white-text">
      </div>
      </form>
    </div>
  </div>


<?php include 'footer.php'; ?>