<?php
	
	include '../include/db.php';
	$id = $_GET['id'];

	if (isset($_POST['submit_profile']) && $_GET['id']) {
		//echo $_GET['id'];

		$image = $_FILES["image"]["name"];
        $path = "upload/".basename($image);

        $sql = "UPDATE `firefighters` SET profile_pic = '$image' WHERE id = '$id'";
       
        $res = mysqli_query($conn,$sql);
        
        // if ($res) {
        // 	echo "Success";
        // }

       move_uploaded_file($_FILES['image']['tmp_name'], $path);
       header("Location:index.php?id=".$id);
	}
?>