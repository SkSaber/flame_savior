  <!-- Footer -->
  <footer class="section grey darken-3 white-text center">
    <p>Flame Savior Copyright &copy; 2018</p>
  </footer>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="../js/materialize.min.js"></script>

  <script>

        $(document).ready(function () {
          $('.dropdown-button').dropdown({
              constrainWidth: true,
              hover: true,
              belowOrigin: true,
              alignment: 'right'
            });

          // JAVASCRIPT START HERE //

          $('.button-collapse').sideNav();


        });

  </script>
</body>

</html>