<?php
  
  include 'header.php';

  $id = $_GET['id'];
  $select = mysqli_query($conn, "SELECT * FROM firefighters WHERE id = '$id'");
  while ($row = mysqli_fetch_array($select)) {


?>
<div class="container">
  <div class="row">
    <div class="col s12 m3 z-depth-1 white" style="height: 0 auto; margin-top: 15px; margin-left: 55px; border-top:2px solid orange; display: block; ">
      <?php if ($row['profile_pic'] == "" ) { ?>
         <div class="img" align="center" style="margin-top: 20px;">
                  <img src="img/pro_pic.gif" id="preview" class="img-responsive circle" style="height: 150px; width: 150px; border: 2px solid #ccc;" alt="UserProfile">
              </div>

              <form action="profile_update.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
                    <span>Upload a profile image.</span>

                    <input type="file" name="image" accept="image/*" onchange="readURL(this);" style="padding: 5px;">

                    <span class="right" style="position: relative; margin-top: -25px; display: block"><input type="submit" name="submit_profile" value="upload"></span>
            </form>

      <?php } else { ?>

      <a href="#popupimage" class="modal-trigger"><img src="upload/<?php echo $row['profile_pic']; ?>" class="img-responsive circle hoverable" style="height: 150px; width: 150px; border: 3px solid #f4f4f4; margin-top: 40px; margin-left: 45px; margin-right: auto;"></a>
    <?php } ?>

      
      <h4 align="center" style="font-weight: bold; font-size: 20px;"><?php echo $row['first_name']." ".$row['last_name']; ?>
      </h4>      
      <p align="center" style="margin-top: -5px;"><?php echo $row['email']; ?></p>
      
      <div class="divider grey lighten-2"></div>
      
      <div class="collection center" style="border: none; padding: 0;">
        
      </div>

          <div class="row col s12">
              <div class="center orange-text hoverable">
                <h5><i class="material-icons small" style="margin-top: 4px;">star</i><br>Firefighter</h5>
                 
               </div>
          </div>

        <div id="popupimage" class="modal">
          <div class="modal-content">
            <img src="upload/<?php echo $row['image']; ?>" class="img-responsive" style="width: 100%;">
          </div>
          <div class="modal-footer">
            <a href="" class="btn">Change</a>
          </div>
        </div>
        <?php } ?>
 
    </div>  

    <div class="col s12 m8" style="margin-top: 5px;">
      <div class="card">
            
      </div>
    </div>