<?php 
function getlatlng($add)
{
	$url = 'https://maps.googleapis.com/maps/api/geocode/json?address='.$add.'&key=AIzaSyB397eQtGvrWNT-2_lGvs9RxVFHjzi6gAc';
	$response = file_get_contents($url);
	$response = json_decode($response, true);
	 
	$lat = $response['results'][0]['geometry']['location']['lat'];
	$long = $response['results'][0]['geometry']['location']['lng'];
	 
	echo "latitude: " . $lat . " longitude: " . $long;
}
// $addr = $_POST['address']; 
// getlatlng($addr);
?>

<?php
function getaddress($lat,$lng)
{
	$url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lat).','.trim($lng).'&key=AIzaSyB397eQtGvrWNT-2_lGvs9RxVFHjzi6gAc';
$json = @file_get_contents($url);
$data=json_decode($json);
$status = $data->status;
if($status=="OK") return $data->results[0]->formatted_address;
else
return false;
}
?>