<?php
	include '../include/db.php';
	session_start();
    if (!isset($_SESSION['id'])) {
      header("Location:login.php");
    }
	$datetime;
	$id = $_GET['id'];
	// echo $_SESSION['id'];
	// echo $id;
	$update = mysqli_query($conn,"UPDATE incident SET status = '1', varified_by_id = '$_SESSION[id]', varified_time = '$datetime' WHERE id = '$id'");
	// if ($update) {
	// 	$notify = mysqli_query($conn,"INSERT INTO `firefighters_notification`(`incident_id`, `varified_by_id`, `fire_station_id`, `status`) VALUES ('$id',)");
	// 	header("Location:details.php?id=".$id);

	// }

?>