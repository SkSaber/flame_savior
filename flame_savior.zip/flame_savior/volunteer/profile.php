<?php
      include '../include/db.php';
      include 'getAddress.php';
      session_start();
      if (!isset($_SESSION['id'])) {
        header("Location:login.php");
      }
?>


<!DOCTYPE html>
<html>

<head>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
  <style type="text/css">
    
  </style>
</head>
<body id="home" class="scrollspy">
  <header class="main-header">
    <div class="primary-overlay">
      <div class="navbar">
        <nav class="transparent">
          <div class="container">
            <div class="nav-wrapper">
              <a href="index.php" class="brand-logo"><img src="../img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
            <a href="#" data-activates="side-nav" class="button-collapse show-on-large right">
              <i class="material-icons">menu</i>
            </a>
            <ul class="right hide-on-med-and-down">
              <li class="active">
                <a href="index.php"><i class="material-icons">home</i></a>
              </li>
              <li>
                  <a class="dropdown-button" data-activates="dropdown" href="#!"><i class="material-icons">notifications</i>
                  </a>
              </li>
              <li>
                  <a class="" href="profile.php?id=<?php echo $_SESSION['id']; ?>"><i class="material-icons">person</i>
                  </a>
              </li>
              <li>
                  <a class="" href="logout.php"><i class="material-icons">exit_to_app</i>
                  </a>
              </li>
            </ul>
            </div>
          </div>
        </nav>
      </div>
      <!-- Dropdowns Notifications -->
      <ul id="dropdown" class="collection with-header latest-comments dropdown-content" style="width: 40%;">
        <li class="collection-header blue-grey">Latest Nofications</li>

        <?php

            $SELECT = mysqli_query($conn, "SELECT * FROM notification
                  JOIN volunteer ON notification.volunteer_id = volunteer.id 
                  JOIN incident ON notification.incident_id = incident.id WHERE notification.status = 'ON' ORDER BY notification.id DESC LIMIT 0,3");

            while ($not_row=mysqli_fetch_array($SELECT)) {
              $fullname = $not_row['firstname']." ".$not_row['lastname'];
              $lat = $not_row['incident_lat'];
              $long = $not_row['incident_long'];
              $incident_id = $not_row['id'];
              $add = getaddress($lat,$long);
              $incident_time = $not_row['incident_time'];

        ?>
             <li class="collection-item avatar">
              <a href="details.php?id=<?php echo $not_row['id']; ?>"><img src="../upload/<?php echo $not_row['image']; ?>" alt="" class="squire" style="height: 100px; width: 100px;">
              <span class="title black-text">Seeking Help from
                <br>"<?php echo $add; ?>"<br>At <?php echo $incident_time; ?>
                </span>
              </a>
              <span class="button"><a href="confirm_incident.php?id=<?php echo $incident_id; ?>" class="btn green">Confirm</a><a href="details.php?id=<?php echo $incident_id; ?>" class="btn red">Details</a></span>
            </li>
          <?php  } ?>
          <li><a class="center indigo-text" href="notifications.php?uid=<?php // echo $user_id; ?>">See all</a></li>
      </ul>
      <!-- Side nav -->
      <ul id="side-nav" class="side-nav">
      <!-- <li>
        <div class="user-view">
          <div class="background">
            <img src="img/ocean.jpg" alt="">
          </div>
          <a href="#">
            <img src="img/person1.jpg" alt="" class="circle">
          </a>
          <a href="#">
            <span class="name white-text">John Doe</span>
          </a>
          <a href="#">
            <span class="email white-text">jdoe@gmail.com</span>
          </a>
        </div>
      </li> -->
      <li class="active">
        <a href="index.php">Home</a>
      </li>
      <li>
        <a href="posts.php">Statistics</a>
      </li>
      <li>
        <a href="categories.php">Incidents</a>
      </li>
      <li>
        <a href="comments.php">Contact</a>
      </li>
      <li>
        <a href="users.php">About Us</a>
      </li>
    </ul>

<div class="container">
  <div class="row">
    <div class="col s12 m3 z-depth-1 white" style="height: 0 auto; margin-top: 15px; margin-left: 55px; border-top:2px solid orange; display: block; ">
      <?php if ($row['profile_pic'] == "" ) { ?>
         <div class="img" align="center" style="margin-top: 20px;">
                  <img src="img/pro_pic.gif" id="preview" class="img-responsive circle" style="height: 150px; width: 150px; border: 2px solid #ccc;" alt="UserProfile">
              </div>

              <form action="profile_update.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
                    <span>Upload a profile image.</span>

                    <input type="file" name="image" accept="image/*" onchange="readURL(this);" style="padding: 5px;">

                    <span class="right" style="position: relative; margin-top: -25px; display: block"><input type="submit" name="submit_profile" value="upload"></span>
            </form>

      <?php } else { ?>

      <a href="#popupimage" class="modal-trigger"><img src="upload/<?php echo $row['profile_pic']; ?>" class="img-responsive circle hoverable" style="height: 150px; width: 150px; border: 3px solid #f4f4f4; margin-top: 40px; margin-left: 45px; margin-right: auto;"></a>
    <?php } ?>

      
      <h4 align="center" style="font-weight: bold; font-size: 20px;"><?php echo $row['first_name']." ".$row['last_name']; ?>
      </h4>      
      <p align="center" style="margin-top: -5px;"><?php echo $row['email']; ?></p>
      
      <div class="divider grey lighten-2"></div>
      
      <div class="collection center" style="border: none; padding: 0;">
        
      </div>

          <div class="row col s12">
              <div class="center orange-text hoverable">
                <h5><i class="material-icons small" style="margin-top: 4px;">star</i><br>Volunteer</h5>
                 
               </div>
          </div>

       
 
    </div>  

    <div class="col s12 m8" style="margin-top: 5px;">
      <div class="card">
            
      </div>
    </div>