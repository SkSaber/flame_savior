<?php 
  include '../include/db.php';
  session_start();
  $error_array = array();
  if (isset($_POST['login_btn'])) {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    $_SESSION['email'] = $email;
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM volunteer WHERE email = '$email' AND password = '$password'");
    $check = mysqli_num_rows($query);

    if ($check == 1) {
      $row = mysqli_fetch_array($query);
      $id = $row['id'];
      $_SESSION['id'] = $id;
      header("Location:index.php?id=$id");
      exit();
    } else {
      array_push($error_array, "Email or password is incorrect<br>");
    }
  }

 ?>
<!DOCTYPE html>
<html>

<head>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/main.css" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
</head>

<body class="grey lighten-4">
  <nav class="grey darken-4">
    <div class="container">
      <div class="nav-wrapper">
        <a href="index.html" class="brand-logo"><img src="../img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
      </div>
    </div>
  </nav>

  <section class="section section-login">
    <div class="container">
      <div class="row">
        <div class="col s12 m8 offset-m2 l6 offset-l3">
          <div class="card-panel login orange lighten-1 white-text center">
            <h4>HELLO FIRE FIGHTER.</h4>
             <span class="red-text white" style="padding: 10px;"><?php if(in_array("Email or password is incorrect<br>", $error_array)) echo "Email or password is incorrect<br>"?></span>
      
            <form action="login.php" method="POST">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="email" id="email" name="email">
                <label class="white-text" for="email">Email</label>
              </div>
              <div class="input-field">
                <i class="material-icons prefix">lock</i>
                <input type="password" id="password" name="password">
                <label class="white-text" for="password">Password</label>
              </div>
              <input type="submit" name="login_btn" value="Login"  class="btn btn-large btn-extended orange lighten-1 white-text">
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="section grey darken-3 white-text center">
    <p>Flame Savior Copyright &copy; 2019</p>
  </footer>



  <!--Import jQuery before materialize.js-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

</body>

</html>