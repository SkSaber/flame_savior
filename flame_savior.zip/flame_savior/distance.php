<?php
	function haversineGreatCircleDistance(
	  $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
	{
	  $latFrom = deg2rad($latitudeFrom);
	  $lonFrom = deg2rad($longitudeFrom);
	  $latTo = deg2rad($latitudeTo);
	  $lonTo = deg2rad($longitudeTo);

	  $latDelta = $latTo - $latFrom;
	  $lonDelta = $lonTo - $lonFrom;

	  $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) +
	    cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));
	  return $angle * $earthRadius;
	}
 $query = @unserialize (file_get_contents('http://ip-api.com/php/'));
 if ($query && $query['status'] == 'success') {

 }
 foreach ($query as $data => $value) {
 	if ($data == 'lat') {
 		$lat=$value;
 	}
 	if ($data == 'lon') {
 		$lon=$value;
 	}
 	if ($data == 'org') {
 		echo "org".$value."<br>";
 	}
 }
 $lat2=24.8949294;
 $lon2=91.8687063;

 $distance=haversineGreatCircleDistance($lat,$lon,$lat2,$lon2);
 if ($distance<=1000)
 {
 	echo "Within the Area!!!";
 }
 ?>