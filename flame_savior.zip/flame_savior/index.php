 <?php
	$query = @unserialize (file_get_contents('http://ip-api.com/php/'));
	if ($query && $query['status'] == 'success') {
	
	}
	foreach ($query as $data => $value) {
	    if ($data == 'lat') {
	    	// echo "lat".$value."<br>";
	    }
	    if ($data == 'lon') {
	    	// echo "lon".$value."<br>";
	    }
	    if ($data == 'org') {
	    	// echo "org".$value."<br>";
	    }
	    
	    // echo $data. "<br>";
	    // echo $value. "<br>";
	}
	
?>


<!DOCTYPE html>
<html>

<head>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
</head>


<body id="home" class="scrollspy">
  <header class="main-header">
    <div class="primary-overlay">
      <div class="navbar">
        <nav class="transparent">
          <div class="container">
            <div class="nav-wrapper">
              <a href="index.php" class="brand-logo"><img src="img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
		        <a href="#" data-activates="side-nav" class="button-collapse right">
		          <i class="material-icons">menu</i>
		        </a>
		        <ul class="right hide-on-med-and-down">
		          <li class="active">
		            <a href="index.php">Home</a>
		          </li>
		          <li>
		            <a href="posts.php">Statistics</a>
		          </li>
		          <li>
		            <a href="categories.php">Incidents</a>
		          </li>
		          <li>
		            <a href="comments.php">Contact</a>
		          </li>
		          <li>
		            <a href="users.php">About Us</a>
		          </li>
		        </ul>
            </div>
          </div>
        </nav>
      </div>
      <!-- Side nav -->
      <ul id="side-nav" class="side-nav">
      <li class="active">
        <a href="index.php">Home</a>
      </li>
      <li>
        <a href="posts.php">Statistics</a>
      </li>
      <li>
        <a href="categories.php">Incidents</a>
      </li>
      <li>
        <a href="comments.php">Contact</a>
      </li>
      <li>
        <a href="users.php">About Us</a>
      </li>
    </ul>
      <!-- Showcase -->
      <div class="showcase container">
        <div class="row">
          <div class="col s7 m8 l8 main-text">
            <h5>WE ARE </h5>
            <h1>Promised to keep you safe.</h1>
            <p class="flow-text">Bangladesh Fire service and sivil Defence</p>
            <br>
            <a href="#about" class="btn btn-large white black-text">Help us support you</a>
          </div>
          <div class="s12 m4 l4 button-emergency">
          	<div align="center" class="">
          		<img src="img/down-arrow.gif" style="height: 100px; width: 150px;">
          		<a href="emergency_service.php" class="btn btn-large red white-text">Emergency Contact</a>
          		<button id="call" class="btn btn-large red white-text" style="width: 240px; margin-top: 5px;">S O S</button>
          		<p class="red-text text-lighten-1">Note: Please Don't use the button without any Emergency Situation occurs.</p>
          	</div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <section class="section section-volunteer center grey lighten-1">
  	<h5>WE WILL APPRICIATE YOUR SUPPORT</h5>
  	<p>Apply for volenteering service.</p>
  	 <a class="btn waves-effect waves-light btn-large orange darken-2 modal-trigger" href="#modal1"> Apply Now</a>
  </section>
  <section class="section ">
  	
  </section>
	
<!-- Add Education Modal -->

<div id="modal1" class="modal">
<div class="modal-content">

	<h4>Apply for volunteer service<span class="right"><button type="button" class="close" data-dismiss="modal1" aria-hidden="true">&times;</button></span></h4>
	
	<div class="divider grey lighten-2"></div>
	<div class="row">
		<div class="col m6 l6">
			<form class="col s12" action="index.php" method="POST">
			<div class="row modal-form-row">
				<div class="input-field col s12">
					<input id="name" name="name" type="text" placeholder="Enter your full name" class="validate">
					<label for="name">Full Name</label>
				</div>
			</div>
			<div class="row">
				<div class="input-field col s12">
					<input id="phone" name="phone" type="number" placeholder="Enter Your Contact Number" class="validate">
					<label for="phone">Contact Number</label>
				</div>
			</div>
			<div class="row">
				<div class="input-field col s12">
					<input id="email" name="email" type="email" placeholder="Enter Your email" class="validate">
					<label for="email">Email</label>
				</div>
			</div>
			<div class="row">
				<button type="submit" class="btn btn-large orange white-text">Apply </button>
			</div>
		</form>
		</div>
    <div class="col s12 m6 l6">
      <img src="img/logo.png" style="width: 400px;">
      <h5 style="font-size: 20px;">Benefit of being a volunteer.</h5>
      <p><i class="material-icons">chevron_right</i></p>
      <p><i class="material-icons">chevron_right</i></p>
      <p><i class="material-icons">chevron_right</i></p>
      <p><i class="material-icons">chevron_right</i></p>
      <h5 align="left">Be A volunteer, Save life.</h5>
    </div>
	</div>
</div>
</div>



 <footer class="section grey darken-3 white-text center">
    <p>Flame Savior Copyright &copy; 2019</p>
  </footer>

   <div id="volunteer-modal" class="modal">
    <div class="modal-content">
      <h4>Add Volunteer</h4>
      <form action="volunteer.php" method="POST">
        <div class="input-field">
          <input type="text" id="firstname" name="firstname">
          <label for="firstname">First Name</label>
        </div>
        <div class="input-field">
          <input type="text" id="lastname" name="lastname">
          <label for="lastname">Last Name</label>
        </div>
        <div class="input-field">
          <input type="email" id="email" name="email">
          <label for="email">Email</label>
        </div>
        <div class="input-field">
          <select class="material-select" name="status">
            <option selected="selected">Activity</option>
            <option value="Yes">Active</option>
            <option value="No">Inactive</option>
          </select>
        </div>
      <div class="modal-footer">
         <input type="submit" name="add_volunteer" class="modal-action modal-close btn blue white-text">
      </div>
      </form>
    </div>
  </div>


  <!--Import jQuery before materialize.js-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

  <script>
    $("#call").on('click', function() {
        var link = "tel:999";
        window.location.href = link;
    });
  </script>

  <script>
      $(document).ready(function () {
        // Show sections
        $('.section').fadeIn();

        // Hide preloader
        $('.loader').fadeOut();

        //Init Side nav
        $('.button-collapse').sideNav();

        // Init Modal
        $('.modal').modal();

        // Init Select
        $('select').material_select();

        $('.modal').modal({
	        dismissible: true,
	        inDuration: 300,
	        outDuration: 200,
	        ready: function (modal, trigger) {
	          console.log('Modal Opened', modal, trigger);
	        }
      });

        // Counter
        $('.count').each(function () {
          $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
          }, {
              duration: 1000,
              easing: 'swing',
              step: function (now) {
                $(this).text(Math.ceil(now));
              }
            });
        });

        // Comments - Approve & Deny
        $('.approve').click(function (e) {
          Materialize.toast('Comment Approved', 3000);
          e.preventDefault();
        });
        $('.deny').click(function (e) {
          Materialize.toast('Comment Denied', 3000);
          e.preventDefault();
        });

        // Quick Todos
        $('#todo-form').submit(function (e) {
          const output = `<li class="collection-item">
                <div>${$('#todo').val()}
                  <a href="#!" class="secondary-content delete">
                    <i class="material-icons">close</i>
                  </a>
                </div>
              </li>`;

          $('.todos').append(output);

          Materialize.toast('Todo Added', 3000);

          e.preventDefault();
        });

        // Delete Todos
        $('.todos').on('click', '.delete', function (e) {
          $(this).parent().parent().remove();
          Materialize.toast('Todo Removed', 3000);

          e.preventDefault();
        });

        CKEDITOR.replace('body');

      });
  </script>
     <script>
	$.ajax({
		url: "https://geoip-db.com/jsonp",
		jsonpCallback: "callback",
		dataType: "jsonp",
		success: function( location ) {
			$('#country').html(location.country_name);
			$('#state').html(location.state);
			$('#city').html(location.city);
			$('#latitude').html(location.latitude);
			$('#longitude').html(location.longitude);
			$('#ipv4').html(location.IPv4);  
		}
	});		
    </script>
</body>

</html>