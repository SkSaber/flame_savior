<?php
    include '../include/db.php';
    include 'header.php';

?>

  <!-- Section: Stats -->
  <section class="section section-stats center">
    <div class="row">
      <div class="col s12 m6 l3">
        <div class="card-panel orange lighten-1 white-text center">
          <i class="material-icons medium">insert_emoticon</i>
          <h5>Incidents</h5>
          <h3 class="count">28300</h3>
          <div class="progress grey lighten-1">
            <div class="determinate white" style="width: 40%;"></div>
          </div>
        </div>
      </div>
      <div class="col s12 m6 l3">
        <div class="card-panel center">
          <i class="material-icons medium">mode_edit</i>
          <h5>Volunteer</h5>
          <h3 class="count">105</h3>
          <div class="progress grey lighten-1">
            <div class="determinate orange lighten-1" style="width: 20%;"></div>
          </div>
        </div>
      </div>
      <div class="col s12 m6 l3">
        <div class="card-panel orange lighten-1 white-text center">
          <i class="material-icons medium">mode_comment</i>
          <h5>Users</h5>
          <h3 class="count">1200</h3>
          <div class="progress grey lighten-1">
            <div class="determinate white" style="width: 40%;"></div>
          </div>
        </div>
      </div>
      <div class="col s12 m6 l3">
        <div class="card-panel center">
          <i class="material-icons medium">supervisor_account</i>
          <h5>Admins</h5>
          <h3 class="count">350</h3>
          <div class="progress grey lighten-1">
            <div class="determinate orange lighten-1" style="width: 10%;"></div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section class="section section-visitors orange lighten-4">
    <div class="row">
      <div class="col s12 m12 l12">
        <div class="card-panel">
          <table class="striped">
            <h4>Recent Incident History</h4>
            <thead>
                <tr>
                  <th>Location</th>
                  <th>Status</th>
                  <th>Incident time</th>
                </tr>
            </thead>
                <?php 

                        $post = mysqli_query($conn, "SELECT * FROM incident WHERE status = '0' LIMIT 0,3");
                        while ($row=mysqli_fetch_array($post)) {
                            $lat = $row['incident_lat'];
                            $lang = $row['incident_long'];
                ?>

                <tr>
                    <td><?php echo $lat." , ".$lang; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo $row['incident_time']; ?></td>
                  <td>
                    <a href="details_view.php?id=<?php echo $row['id']; ?>" class="btn blue lighten-2">Details</a>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>




<?php include 'footer.php'; ?>