<?php 
    include '../include/db.php';
    include 'header.php'; 
    include 'getAddress.php';
?>


  <!-- Section: Posts -->
  <section class="section section-posts grey lighten-4">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card">
            <div class="card-content">
              <span class="card-title">Posts</span>
              <table class="striped">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th>Incident Location</th>
                    <th>Incident Reason</th>
                    <th>Image</th>
                    <th>Varified By</th>
                    <th>Incident Time</th>
                    <th>Rescue Time</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                      $select = mysqli_query($conn,"SELECT * FROM incident JOIN volunteer ON incident.varified_by_id = volunteer.id");
                      $sr = 1;
                      while ($row = mysqli_fetch_array($select)) {
                        
                        $lat = $row['incident_lat'];
                        $long = $row['incident_long'];
                        $address = getaddress($lat,$long);
                        $name = $row['first_name']." ".$row['last_name'];
                  ?>
                  <tr>
                    <td><?php echo $sr; ?></td>
                    <td><?php echo $address; ?></td>
                    <td><?php echo $row['incident_reason']; ?></td>
                    <td><img src="../upload/<?php echo $row['image']; ?>" style="height: 50px; width:70px;"></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $row['incident_time']; ?></td>
                    <td><?php echo $row['rescue_time']; ?></td>
                    <td>
                      <a href="delete.php"><i class="material-icons red-text">delete</i></a>
                    </td>
                  </tr>
                <?php $sr++; } ?>
                </tbody>
              </table>
            </div>

            <div class="card-action">
              <ul class="pagination">
                <li class="disabled">
                  <a href="#!" class="orange-text">
                    <i class="material-icons">chevron_left</i>
                  </a>
                </li>
                <li class="active orange lighten-2">
                  <a href="#!" class="white-text">1</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">2</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">3</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">4</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">5</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">
                    <i class="material-icons">chevron_right</i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php include 'footer.php'; ?>