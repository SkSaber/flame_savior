<?php include 'header.php'; ?>
  <!-- Section: Details -->
  
  <section class="section section-details grey lighten-4">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card">
            <div class="card-content">
              <div class="row">
                <div class="col s12 m6">
                  <span class="card-title">Incident Details</span>
                </div>
                
              </div>

              

            </div>
            <div class="card-action">
              <button class="btn green">Save</button>
              <button class="btn red">Delete</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php include 'footer.php'; ?>