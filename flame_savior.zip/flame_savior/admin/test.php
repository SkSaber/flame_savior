<!DOCTYPE html>
<html>
<body>
<form method="post" action="getAddress.php">
Latitude:<br>
<input type="text" name="latitude">
<br>
Longitude:<br>
<input type="text" name="longitude">
<br>
<br>
<input type="submit" value="submit">
</form>
</body>
</html>