<?php 
    include '../include/db.php';
    include 'header.php'; 
    include 'getAddress.php';
    if (isset($_POST['add_station'])) {
      $station = $_POST['station'];
      if (!empty($station)) {
        $ins = mysqli_query($conn,"INSERT INTO `fire_station`(`location_lat`, `location_long`) VALUES ([value-2],[value-3])");
      }
    }
?>
  <!-- Section: Categories -->
  <section class="section section-categories grey lighten-4">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card">
            <div class="card-content">
                <span class="card-title">Stations<span class="right"><a href="#category-modal" class="modal-trigger btn-large red">ADD STATION</a></span></span>
              <table class="striped">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th>Location</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $select = mysqli_query($conn,"SELECT * FROM fire_station");
                      while ($row= mysqli_fetch_array($select)) {
                        $sr = 1;
                        $lat = $row['location_lat'];
                        $long = $row['location_long'];
                        $address = getaddress($lat,$long);
                        // echo $lat."<br>";
                        // echo $long;
                  ?>
                  <tr>
                    <td><?php echo $sr; ?></td>
                    <td><?php echo $address; ?></td>
                  </tr>
                  <?php $sr++; } ?>
                </tbody>
              </table>
            </div>
            <div class="card-action">
              <ul class="pagination">
                <li class="disabled">
                  <a href="#!" class="orange-text">
                    <i class="material-icons">chevron_left</i>
                  </a>
                </li>
                <li class="active orange lighten-2">
                  <a href="#!" class="white-text">1</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">2</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">3</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">4</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">5</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">
                    <i class="material-icons">chevron_right</i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Add Category Modal -->
  <div id="category-modal" class="modal">
    <div class="modal-content">
      <h4>Add Stations</h4>
      <form action="stations.php" method="POST">
        <div class="input-field">
          <input type="text" id="station" name="station">
          <label for="station">Station Name</label>
        </div>
      </form>
      <div class="modal-footer">
        <button type="submit" name="add_station"></button>
      </div>
    </div>
  </div>


<?php include 'footer.php'; ?>