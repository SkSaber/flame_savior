<!DOCTYPE html>
<html>

<head>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="../css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="../css/style.css" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
</head>

<body class="grey lighten-4">
  <nav class="grey darken-4">
    <div class="container">
      <div class="nav-wrapper">
        <a href="index.php" class="brand-logo"><img src="../img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
        <a href="#" data-activates="side-nav" class="button-collapse show-on-large right">
          <i class="material-icons">menu</i>
        </a>
        <ul class="right hide-on-med-and-down">
          <li class="active">
            <a href="index.php">Dashboard</a>
          </li>
          <li>
            <a href="survey.php">Survey</a>
          </li>
          <li>
            <a href="stations.php">Fire Stations</a>
          </li>
          <li>
            <a href="incidents.php">Incidents</a>
          </li>
          <li>
            <a class="dropdown-button" data-activates="my-dropdown" href="#!">Manage
              <i class="material-icons right">arrow_drop_down</i>
            </a>
          </li>
        </ul>
        <ul id="my-dropdown" class="dropdown-content">
          <li>
            <a href="users.php">Users</a>
          </li>
          <li>
            <a href="volunteer.php">Volunteer</a>
          </li>
          <li>
            <a href="fire_fighters.php">Fire Fighters</a>
          </li>
        </ul>
        <!-- Side nav -->
        <ul id="side-nav" class="side-nav">
          <li>
            <div class="user-view">
              <div class="background">
                <img src="img/ocean.jpg" alt="">
              </div>
              <a href="#">
                <img src="img/person1.jpg" alt="" class="circle">
              </a>
              <a href="#">
                <span class="name white-text">John Doe</span>
              </a>
              <a href="#">
                <span class="email white-text">jdoe@gmail.com</span>
              </a>
            </div>
          </li>
          <li>
            <a href="index.php">
              <i class="material-icons">dashboard</i> Dashboard</a>
          </li>
          <li>
            <a href="posts.php">Posts</a>
          </li>
          <li>
            <a href="stations.php">Categories</a>
          </li>
          <li>
            <a href="comments.php">Comments</a>
          </li>
          <li>
            <a href="users.php">Users</a>
          </li>
          <li>
            <div class="divider"></div>
          </li>
          <li>
            <a class="subheader">Account Controls</a>
          </li>
          <li>
            <a href="login.php" class="waves-effect">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>