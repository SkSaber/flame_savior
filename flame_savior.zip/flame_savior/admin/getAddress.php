<?php 
function getaddress($lat,$lng)
{
	$url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lat).','.trim($lng).'&key=AIzaSyB397eQtGvrWNT-2_lGvs9RxVFHjzi6gAc';
		$json = @file_get_contents($url);
		$data=json_decode($json);
		$status = $data->status;
		if($status=="OK") return $data->results[0]->formatted_address;
		else
		return false;
		}

?>