<?php 
    include '../include/db.php';
    include 'header.php'; 
  

  if (isset($_POST['add_fire_fighters'])) {

    $firstname = strip_tags($_POST['firstname']);
    $firstname = str_replace(' ', '', $firstname);
    $firstname = ucfirst(strtolower($firstname));
    $_SESSION['firstname'] = $firstname;

    $lastname = strip_tags($_POST['lastname']);
    $lastname = str_replace(' ', '', $lastname);
    $lastname = ucfirst(strtolower($lastname));
    $_SESSION['lastname'] = $lastname;

    $email = strip_tags($_POST['email']);
    $email = str_replace(' ', '', $email);
    $email = ucfirst(strtolower($email));
    $_SESSION['email'] = $email;

  if (filter_var($email, FILTER_VALIDATE_EMAIL))
  {
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    $checkEmail = mysqli_query($conn, "SELECT * FROM firefighters WHERE email = '$email'");
    $rows = mysqli_num_rows($checkEmail);
    if ($rows > 0) 
    {
      echo "Email Exist";
    }
    
  } 

    $password = substr(str_shuffle(str_repeat("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 5)), 0, 8);

    $insert = mysqli_query($conn, "INSERT INTO `firefighters`(`fire_station_name`, `first_name`, `last_name`, `father_name`, `mother_name`, `nid`, `address`, `phone`, `email`, `password`) VALUES ('','$firstname','$lastname','','','','','','$email','$password')");

    if ($insert) {
    $emailTo =  $email;
    $subject = "Fire Fighter Confirmation";
    $body = "Hello ".$firstname.", We are pleasently inform you that, 
          you are Now a honorable member of Bangladesh Fire Fighters..<br> Please log in with this credentials..<br>
          Email:".$email." <br> Password   ".$password."";

    $headers = "From: atiqur.ra2017@gmail.com";
    if (mail($emailTo, $subject,$body,$headers)) {
      echo "Mail successfuly sent";
    } else {
      echo "Failed";
    }

    } 


  }
?>
  <!-- Section: Categories -->
  <section class="section section-categories grey lighten-4">
    <div class="container">
      <div class="row">
        <div class="col s12">
          <div class="card">
            <div class="card-content">
                <span class="card-title">Stations<span class="right"><a href="#user-modal" class="modal-trigger btn-large red">Add Fire Fighters</a></span></span>
              <table class="striped">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th></th>
                    <th>Name</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>NID</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Fire Station</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $select = mysqli_query($conn,"SELECT * FROM firefighters");
                      while ($row= mysqli_fetch_array($select)) {
                        $sr = 1;
                  ?>
                  <tr>
                    <td><?php echo $sr; ?></td>
                    <td width="70"></td>
                    <td><?php echo $row['first_name']." ".$row['last_name']; ?></td>
                    <td><?php echo $row['father_name']; ?></td>
                    <td><?php echo $row['mother_name']; ?></td>
                    <td><?php echo $row['nid']; ?></td>
                    <td><?php echo $row['address']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['fire_station_name']; ?></td>
                  </tr>
                  <?php $sr++; } ?>
                </tbody>
              </table>
            </div>
            <!-- <div class="card-action">
              <ul class="pagination">
                <li class="disabled">
                  <a href="#!" class="orange-text">
                    <i class="material-icons">chevron_left</i>
                  </a>
                </li>
                <li class="active orange lighten-2">
                  <a href="#!" class="white-text">1</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">2</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">3</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">4</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">5</a>
                </li>
                <li class="waves-effect">
                  <a href="#!" class="orange-text">
                    <i class="material-icons">chevron_right</i>
                  </a>
                </li>
              </ul>
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Add Fire Fighters Modal -->
  <div id="user-modal" class="modal">
    <div class="modal-content">
      <h4>Add Fire Fighter</h4>
      <form action="fire_fighters.php" method="POST">
        <div class="input-field">
          <input type="text" id="firstname" name="firstname">
          <label for="firstname">First Name</label>
        </div>
        <div class="input-field">
          <input type="text" id="lastname" name="lastname">
          <label for="lastname">Last Name</label>
        </div>
        <div class="input-field">
          <input type="email" id="email" name="email">
          <label for="email">Email</label>
        </div>
      <div class="modal-footer">
         <input type="submit" name="add_fire_fighters" class="modal-action modal-close btn blue white-text">
      </div>
      </form>
    </div>
  </div>


<?php include 'footer.php'; ?>