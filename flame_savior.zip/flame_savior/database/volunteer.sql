-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2019 at 06:24 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flame_savior`
--

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE `volunteer` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `nid` int(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(500) NOT NULL,
  `address_lat` varchar(200) NOT NULL,
  `address_long` varchar(200) NOT NULL,
  `training_status` varchar(20) NOT NULL,
  `training_date` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `reg_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `volunteer`
--

INSERT INTO `volunteer` (`id`, `first_name`, `last_name`, `nid`, `email`, `password`, `profile_pic`, `address_lat`, `address_long`, `training_status`, `training_date`, `status`, `reg_date`) VALUES
(1, 'Nowshin', 'Yesmin', 0, 'Mshine254@gmail.com', 'R7H9YABR', '', '24.9528', '91.8739', '', '', 'Yes', 'April-19-2019 12:49'),
(2, 'Saber', 'Ali', 0, 'Sksaber119th@gmail.com', 'RAPMB2B6', '', '24.93492', '91.8787063', '', '', 'Yes', 'April-19-2019 12:58'),
(3, 'Saber', 'Ali', 0, 'Sksaber19th@gmail.com', 'PWTG7A6C', '', '24.9211', '91.86522', '', '', 'Yes', 'April-19-2019 12:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `volunteer`
--
ALTER TABLE `volunteer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `volunteer`
--
ALTER TABLE `volunteer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
