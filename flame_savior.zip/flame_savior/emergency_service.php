<?php
    
    include 'include/db.php';
    function haversineGreatCircleDistance(
    $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
    {
      $latFrom = deg2rad($latitudeFrom);
      $lonFrom = deg2rad($longitudeFrom);
      $latTo = deg2rad($latitudeTo);
      $lonTo = deg2rad($longitudeTo);

      $latDelta = $latTo - $latFrom;
      $lonDelta = $lonTo - $lonFrom;

      $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) +
        cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));
      return $angle * $earthRadius;
    }

    $query = @unserialize (file_get_contents('http://ip-api.com/php/'));
    if ($query && $query['status'] == 'success') {
    
    }
    
    foreach ($query as $data => $value) {
        if ($data == 'lat') {
         $lat = $value;
        }
        if ($data == 'lon') {
          $long = $value;
        }

        if ($data == 'org') {
          $loc = $value;
        }
        
        // echo $data. "<br>";
        // echo $value. "<br>";
    }
    

    $error = array();
    if (isset($_POST['help'])) {
      $location_lat = $lat;
      $location_long = $long;

      $image = $_FILES["image"]["name"];
      $path = "upload/".basename($image);

      $datetime;

      if (empty($image)) {
        echo "Every Field Must be filled out";
      } else {
        $ins = mysqli_query($conn,"INSERT INTO `incident`(`incident_lat`, `incident_long`, `incident_reason`, `image`, `varified_by_id`, `status`,`incident_time`, `varified_time`, `rescue_time`) VALUES ('$location_lat','$location_long','','$image','0','0','$datetime','','')");
        move_uploaded_file($_FILES['image']['tmp_name'], $path);

        if ($ins) {
          $select = mysqli_query($conn,"SELECT * FROM volunteer");
          while($row = mysqli_fetch_array($select)){
            $id = $row['id'];
            $lat2 = $row['address_lat'];
            $long2 = $row['address_long'];
            $dis = haversineGreatCircleDistance($location_lat,$location_long,$lat2,$long2);
            if ($dis <= 1000) {
              $incident = mysqli_query($conn,"SELECT * FROM incident ORDER BY id DESC LIMIT 1");
              $roe = mysqli_fetch_array($incident);
              $ins_id = $roe['id'];
              // echo $ins_id;
              $datetime;
              $notify = mysqli_query($conn,"INSERT INTO `notification`(`incident_id`, `volunteer_id`, `date_time`) VALUES ('$ins_id','$id','$datetime')");
              if ($notify) {
                array_push($error, "Success");
              }
            }
          }
          
        }
        
      }

    }
?>

<!DOCTYPE html>
<html>

<head>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="css/style.css" />

  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flame Savior</title>
</head>

<body class="grey lighten-4">
  <nav class="grey darken-4">
    <div class="container">
      <div class="nav-wrapper">
        <a href="index.php" class="brand-logo"><img src="img/logo.png" alt="FLAME SAVIOR" style="height: 70px; width: 250px;"></a>
            <a href="#" data-activates="side-nav" class="button-collapse show-on-large right">
              <i class="material-icons">menu</i>
            </a>
            <ul class="right hide-on-med-and-down">
              <li class="active">
                <a href="index.php">Home</a>
              </li>
              <li>
                <a href="posts.php">Statistics</a>
              </li>
              <li>
                <a href="categories.php">Incidents</a>
              </li>
              <li>
                <a href="comments.php">Contact</a>
              </li>
              <li>
                <a href="users.php">About Us</a>
              </li>
            </ul>
            </div>
          </div>
        </nav>
      </div>
        <!-- Side nav -->
        <ul id="side-nav" class="side-nav">
        <!-- <li>
          <div class="user-view">
            <div class="background">
              <img src="img/ocean.jpg" alt="">
            </div>
            <a href="#">
              <img src="img/person1.jpg" alt="" class="circle">
            </a>
            <a href="#">
              <span class="name white-text">John Doe</span>
            </a>
            <a href="#">
              <span class="email white-text">jdoe@gmail.com</span>
            </a>
          </div>
        </li> -->
        <li class="active">
          <a href="index.php">Home</a>
        </li>
        <li>
          <a href="posts.php">Statistics</a>
        </li>
        <li>
          <a href="categories.php">Incidents</a>
        </li>
        <li>
          <a href="comments.php">Contact</a>
        </li>
        <li>
          <a href="users.php">About Us</a>
        </li>
      </ul>
      </div>
    </div>
  </nav>

  <section class="section grey lighten-2 center black-text">
    <div class="container">
      <div class="row">
        <h4>Seek Help from Fire Station</h4>
        <p>Please varify Your place.</p>
        <div class="divider grey lighten-2"></div>
        <form action="emergency_service.php" method="post" enctype="multipart/form-data">
          <div class="col s12 m5 l5">
            <div class="input-field">
              <i class="material-icons prefix">location_on</i>
              <input id="location" type="text" value="<?php echo $loc; ?>">
              <label for="location">Location</label>
            </div>
           </div>

           <div class="col s12 m4 l4">
             <div class="file-field input-field">
              <div class="btn orange white-text">
                <span>Take a picture of the place.</span>
                <input type="file" name="image" accept="image/*" capture="camera">
              </div>
              <div class="file-path-wrapper">
                <input type="text" class="file-path">
              </div>
            </div>
           </div>
           <div class="col s12 m3 l3">
             <div class="button">
               <button class="btn btn-large orange darken-4 white-text" type="submit" name="help">Submit For Help</button>
             </div>
           </div> 
          </form>
        </div>
        <?php if (in_array("Success",$error)) { ?>

            <p class="green-text"><b><?php echo "Success";?></b></p>

          
        <?php } ?>
      </div>
    </div>
  </section>


 <footer class="section grey darken-3 white-text center" style="margin-top: 400px;">
    <p>Flame Savior Copyright &copy; 2019</p>
  </footer>
  <!--Import jQuery before materialize.js-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

  <script>
    // Hide Sections
    $('.section').hide();

   
      $(document).ready(function () {
        // Show sections
        $('.section').fadeIn();

        // Hide preloader
        $('.loader').fadeOut();

        //Init Side nav
        $('.button-collapse').sideNav();

        // Init Modal
        $('.modal').modal();

        // Init Select
        $('select').material_select();

        // Counter
        $('.count').each(function () {
          $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
          }, {
              duration: 1000,
              easing: 'swing',
              step: function (now) {
                $(this).text(Math.ceil(now));
              }
            });
        });

        // Comments - Approve & Deny
        $('.approve').click(function (e) {
          Materialize.toast('Comment Approved', 3000);
          e.preventDefault();
        });
        $('.deny').click(function (e) {
          Materialize.toast('Comment Denied', 3000);
          e.preventDefault();
        });

        // Quick Todos
        $('#todo-form').submit(function (e) {
          const output = `<li class="collection-item">
                <div>${$('#todo').val()}
                  <a href="#!" class="secondary-content delete">
                    <i class="material-icons">close</i>
                  </a>
                </div>
              </li>`;

          $('.todos').append(output);

          Materialize.toast('Todo Added', 3000);

          e.preventDefault();
        });

        // Delete Todos
        $('.todos').on('click', '.delete', function (e) {
          $(this).parent().parent().remove();
          Materialize.toast('Todo Removed', 3000);

          e.preventDefault();
        });

        CKEDITOR.replace('body');

      });
  
  </script>
     <script>
  $.ajax({
    url: "https://geoip-db.com/jsonp",
    jsonpCallback: "callback",
    dataType: "jsonp",
    success: function( location ) {
      $('#country').html(location.country_name);
      $('#state').html(location.state);
      $('#city').html(location.city);
      $('#latitude').html(location.latitude);
      $('#longitude').html(location.longitude);
      $('#ipv4').html(location.IPv4);  
    }
  });   
    </script>
</body>

</html>